import 'package:flutter/material.dart';
import 'package:chinesefood/models/food.dart';
import 'package:chinesefood/services/api_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FoodListScreen extends StatefulWidget {
  @override
  _FoodListScreenState createState() => _FoodListScreenState();
}

class _FoodListScreenState extends State<FoodListScreen> {
  List<Food> _foodList = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadFoodList();
  }

  void _loadFoodList() async {
    try {
      List<dynamic> foodListData = await ApiService.getFoodList();
      setState(() {
        _foodList = foodListData.map((data) => Food.fromJson(data)).toList();
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading food list: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.remove('isLoggedIn');
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Food List'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: _logout,
          ),
        ],
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: _foodList.length,
        itemBuilder: (context, index) {
          Food food = _foodList[index];
          print("Food Item: ${food.title}, Image URL: ${food.image}");
          return Card(
            child: ListTile(
              leading: food.image.isNotEmpty
                  ? Image.network(food.image)
                  : Container(width: 50, height: 50, color: Colors.grey),
              title: Text(food.title),
              onTap: () {
                Navigator.pushNamed(
                  context,
                  '/food_detail',
                  arguments: {'id': food.id},
                );
              },
            ),
          );
        },
      ),
    );
  }
}
