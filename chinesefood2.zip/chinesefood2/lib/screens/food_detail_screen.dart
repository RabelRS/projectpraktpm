import 'package:flutter/material.dart';
import 'package:chinesefood/services/api_service.dart';

class FoodDetailScreen extends StatefulWidget {
  final Map<String, dynamic> arguments;

  FoodDetailScreen({required this.arguments});

  @override
  _FoodDetailScreenState createState() => _FoodDetailScreenState();
}

class _FoodDetailScreenState extends State<FoodDetailScreen> {
  Map<String, dynamic> _foodDetail = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadFoodDetail();
  }

  void _loadFoodDetail() async {
    String id = widget.arguments['id'];
    try {
      Map<String, dynamic> foodDetail = await ApiService.getFoodDetail(id);
      setState(() {
        _foodDetail = foodDetail;
        _isLoading = false;
      });
    } catch (e) {
      print('Error loading food detail: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Food Detail'),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
        padding: EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _foodDetail['image_url'] != null
                  ? Image.network(_foodDetail['image_url'])
                  : Container(height: 200, color: Colors.grey),
              SizedBox(height: 10.0),
              Text(
                'Ingredients: ${_foodDetail['ingredients'] ?? 'No ingredients available'}',
                style: TextStyle(fontSize: 18.0),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
