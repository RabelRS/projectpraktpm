class Food {
  final String id;
  final String title;
  final String difficulty;
  final String image;
  final String description; // Tambahkan properti description

  Food({
    required this.id,
    required this.title,
    required this.difficulty,
    required this.image,
    required this.description, // Tambahkan properti description
  });

  factory Food.fromJson(Map<String, dynamic> json) {
    return Food(
      id: json['id'] ?? '',
      title: json['title'] ?? '',
      difficulty: json['difficulty'] ?? '',
      image: json['image'] ?? '',
      description: json['description'] ?? '', // Perbarui metode ini
    );
  }
}
