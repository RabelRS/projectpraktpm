import 'package:flutter/material.dart';
import 'package:chinesefood/screens/login_screen.dart';
import 'package:chinesefood/screens/register_screen.dart';
import 'package:chinesefood/screens/food_list_screen.dart';
import 'package:chinesefood/screens/food_detail_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  Future<bool> _checkLoginStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getBool('isLoggedIn') ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Chinese Food App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: FutureBuilder(
        future: _checkLoginStatus(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator();
          } else {
            return snapshot.data == true ? FoodListScreen() : LoginScreen();
          }
        },
      ),
      routes: {
        '/login': (context) => LoginScreen(),
        '/register': (context) => RegisterScreen(),
        '/food_list': (context) => FoodListScreen(),
        '/food_detail': (context) => FoodDetailScreen(arguments: ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>),
      },
    );
  }
}
