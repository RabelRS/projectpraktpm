import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String apiKey = '633b293a56msh282ab15f322c973p1b4689jsn254601a655ac';
  static const String baseUrl = 'https://chinese-food-db.p.rapidapi.com';

  static Future<List<dynamic>> getFoodList() async {
    final response = await http.get(
      Uri.parse('$baseUrl'),
      headers: {
        'X-RapidAPI-Key': apiKey,
        'X-RapidAPI-Host': 'chinese-food-db.p.rapidapi.com',
      },
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      print("Food List Data: $data"); // Logging response
      return data;
    } else {
      throw Exception('Failed to load food list');
    }
  }

  static Future<Map<String, dynamic>> getFoodDetail(String id) async {
    final response = await http.get(
      Uri.parse('$baseUrl/$id'),
      headers: {
        'X-RapidAPI-Key': apiKey,
        'X-RapidAPI-Host': 'chinese-food-db.p.rapidapi.com',
      },
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      print("Food Detail Data: $data"); // Logging response
      return data;
    } else {
      throw Exception('Failed to load food detail');
    }
  }
}
