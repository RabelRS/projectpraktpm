package com.example.chinesefood;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
